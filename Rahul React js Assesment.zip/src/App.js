import React from 'react';
import { useMemo } from 'react';
import { useState,useEffect } from 'react';
// import "react-table-6/react-table.css"
import { MantineReactTable } from 'mantine-react-table';
import { Button } from '@mantine/core';


// const [pagination, setPagination] = useState(0)
//  //customize the default page size
// ;
// useEffect(() => {
//   //do something when the pagination state changes
// }, [pagination.pageIndex, pagination.pageSize]);

//data definitions...
export const data = [
  {
    id: '1',
    firstName: 'Rahul',
    lastName: 'Srivatsav',
    address: '1,Rahul Street,Rahul Avenue',
    city: 'Chennai',
    state: 'TamilNadu',
    subRows: [
      {
        id: '2',
        firstName: 'Franklin',
        lastName: 'Reinger',
        address: '566 Brakus Inlet',
        city: 'South California',
        state: 'West Virginia',
        subRows: [
          {
            id: '3',
            firstName: 'Ganesh',
            lastName: 'Homenick',
            address: '1234 Doha street',
            city: 'Saudi Arabia',
            state: 'South Doha',
          },
          {
            id: '4',
            firstName: 'Muhammed ',
            lastName: 'Sarfraz',
            address: '4882 Morgan Street',
            city: 'Canneberra',
            state: 'Australia',
          },
        ],
      },
      {
        id: '5',
        firstName: 'Triambika',
        lastName: 'McCullough',
        address: '722 Emie Stream',
        city: 'Lincoln',
        state: 'Nebraska',
      },
    ],
  },
  {
    id: '6',
    firstName: 'Bruce',
    lastName: 'Wayne',
    address: '769 Dominic Grove',
    city: 'Columbus',
    state: 'Ohio',
    subRows: [
      {
        id: '7',
        firstName: 'Tony',
        lastName: 'Stark',
        address: '32188 Larkin Turnpike',
        city: 'Charleston',
        state: 'South Carolina',
        subRows: [
          {
            id: '8',
            firstName: 'Peter',
            lastName: 'Parkar',
            address: '1234 Brakus Inlet',
            city: 'Nashville',
            state: 'Tennessee',
          },
        ],
      },
    ],
  },
];
//end


const Example = () => {
  const columns = useMemo(
    //column definitions...
    () => [
      {
        accessorKey: 'firstName',
        header: 'First Name',
      },
      {
        accessorKey: 'lastName',
        header: 'Last Name',
      },

      {
        accessorKey: 'address',
        header: 'Address',
      },
      {
        accessorKey: 'city',
        header: 'City',
      },

      {
        accessorKey: 'state',
        enableColumnOrdering: false,
        header: 'State',
      },
    ],
    [],
    //end
    
  );

  const initialExpandedRootRows = useMemo(
    () =>
      data
        .map((originalRow) => originalRow.id) //get all the root row ids, use recursion for additional levels
        .reduce((a, v) => ({ a, v: true }), {}), //convert to an object with all the ids as keys and `true` as values
    [],
  );
  

  return (
    
    <MantineReactTable
      columns={columns}
      data={data}
      enableExpanding
      
  // initialState={{ pagination: { pageSize: 25, pageIndex: 2 } }}
      // onPaginationChange={setPagination} //hoist pagination state to your state when it changes internally
      // state={{ pagination }} //pass the pagination state to the table
      getRowId={(originalRow) => originalRow.id}
      initialState={{ expanded: initialExpandedRootRows }} //only expand the root rows by default
      renderTopToolbarCustomActions={({ table }) => (
        <Button onClick={() => table.resetExpanded()}>Reset Expanded</Button>
      )}
      
      
    />
  );
};

export default Example;